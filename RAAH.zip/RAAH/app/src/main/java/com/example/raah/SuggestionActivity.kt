package com.example.raah

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast


class SuggestionActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_suggestion)

        val submit_btn = findViewById<Button>(R.id.btnSubmit)
        submit_btn.setOnClickListener {
            Toast.makeText(this@SuggestionActivity, "Response taken, thanks for your feedback!", Toast.LENGTH_SHORT).show()
        }
    }
}