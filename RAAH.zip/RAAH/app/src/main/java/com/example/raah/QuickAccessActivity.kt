package com.example.raah

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class QuickAccessActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_quick_access)

        val set_btn = findViewById<Button>(R.id.settings_btn)
        set_btn.setOnClickListener {
            val intent = Intent(this@QuickAccessActivity, SettingsActivity::class.java)
            startActivity(intent)
        }
        val report_btn = findViewById<Button>(R.id.report_btn)
        report_btn.setOnClickListener {
            val intent = Intent(this@QuickAccessActivity, ReportActivity::class.java)
            startActivity(intent)
        }
        val routes_btn = findViewById<Button>(R.id.alt_route_btn)
        routes_btn.setOnClickListener {
            val intent = Intent(this@QuickAccessActivity, RoutesActivity::class.java)
            startActivity(intent)
        }
        val emer_btn = findViewById<Button>(R.id.emergency_btn)
        emer_btn.setOnClickListener {
            val intent = Intent(this@QuickAccessActivity, RoutesActivity::class.java)
            startActivity(intent)
        }
        val add_btn = findViewById<Button>(R.id.info_btn)
        add_btn.setOnClickListener {
            val intent = Intent(this@QuickAccessActivity, SuggestionActivity::class.java)
            startActivity(intent)
        }
    }
}